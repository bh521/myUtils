﻿namespace Rebus.Compression
{
    abstract class ZipDecoratorBase
    {
        public const string GzipEncodingHeader = "gzip";
    }
}