﻿namespace Rebus.Tests
{
    public class Categories
    {
        public const string SqlServer = "sqlserver";
        public const string Msmq = "msmq";
        public const string Filesystem = "filesystem";
    }
}