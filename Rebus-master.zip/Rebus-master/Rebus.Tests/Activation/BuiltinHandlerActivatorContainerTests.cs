﻿using NUnit.Framework;
using Rebus.Tests.Contracts.Activation;

namespace Rebus.Tests.Activation
{
    [TestFixture]
    public class BuiltinHandlerActivatorContainerTests : ContainerTests<BuiltinActivationContext> { }
}