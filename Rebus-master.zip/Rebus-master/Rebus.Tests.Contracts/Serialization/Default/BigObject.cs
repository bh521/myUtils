﻿namespace Rebus.Tests.Contracts.Serialization.Default
{
    public class BigObject
    {
        public int Integer { get; set; }
        public string String { get; set; }
    }
}