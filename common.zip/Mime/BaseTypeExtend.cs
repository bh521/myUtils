﻿using System;
using System.Text;
namespace ZoeSoft
{
    public static class BaseTypeExtend
    {
        private const long _NULL_LONG = long.MinValue;
        private const int _NULL_INT = int.MinValue;
        private const decimal _NULL_DECIMAL = decimal.MinValue;
        private const double _NULL_DOUBLE = double.MinValue;
        /// <summary>
        /// 数据类型转换
        /// </summary>
        /// <typeparam name="T">目标数据类型</typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static T To<T>(this object value)
        {
            return To<T>(value, "ZERO");
        }
        /// <summary>
        /// 说明：如果空值返回空值自定义类型
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static T To<T>(this object value, string NULLFlag)
        {
            long NULL_LONG = 0;
            int NULL_INT = 0;
            decimal NULL_DECIMAL = 0;
            double NULL_DOUBLE = 0;
            if (NULLFlag == "MIN")
            {
                NULL_LONG = _NULL_LONG;
                NULL_INT = _NULL_INT;
                NULL_DECIMAL = _NULL_DECIMAL;
                NULL_DOUBLE = _NULL_DOUBLE;
            }
            else
            {
                NULL_LONG = 0;
                NULL_INT = 0;
                NULL_DECIMAL = 0;
                NULL_DOUBLE = 0;
            }
            if (value.IsNull())
            {
                //返回空值
                object obj = null;
                if (typeof(T) == typeof(string))
                {
                    obj = string.Empty;
                }
                else if (typeof(T) == typeof(long))
                {
                    obj = NULL_LONG;
                }
                else if (typeof(T) == typeof(Int32))
                {
                    obj = NULL_INT;
                }
                else if (typeof(T) == typeof(double))
                {
                    obj = NULL_DOUBLE;
                }
                else if (typeof(T) == typeof(decimal))
                {
                    obj = NULL_DECIMAL;
                }
                else if (typeof(T) == typeof(DateTime))
                {
                    obj = DateTime.MinValue;
                }
                else
                {
                    throw new Exception("未知的数据类型[" + value.GetType().Name + "]");
                }
                return (T)obj;
            }
            else
            {
                return ConvertType<T>(value);
            }
        }
        /// <summary>
        /// 如果本身不为空则返回，否则返回所给的数据
        /// </summary>
        /// <typeparam name="T">数据类型</typeparam>
        /// <param name="value"></param>
        /// <param name="value2">目标数据</param>
        /// <returns></returns>
        public static T NVL<T>(this object value, T value2)
        {
            if (value.IsNull())
                return value2;
            return ConvertType<T>(value);
        }
        private static T ConvertType<T>(object value)
        {
            object obj;
            try
            {
                if (typeof(T) == typeof(string))
                {
                    obj = Convert.ToString(value);
                }
                else if (typeof(T) == typeof(long))
                {
                    obj = Convert.ToInt64(value);
                }
                else if (typeof(T) == typeof(int))
                {
                    obj = Convert.ToInt32(value);
                }
                else if (typeof(T) == typeof(decimal))
                {
                    obj = Convert.ToDecimal(value);
                }
                else if (typeof(T) == typeof(double))
                {
                    obj = Convert.ToDouble(value);
                }
                else if (typeof(T) == typeof(bool))
                {
                    obj = Convert.ToBoolean(value);
                }
                else if (typeof(T) == typeof(DateTime))
                {
                    try
                    {
                        obj = Convert.ToDateTime(value);
                    }
                    catch (Exception e)
                    {
                        obj = null;
                    }
                }
                else
                {
                    throw new Exception("未知数据类型[" + typeof(T).Name + "]");
                }
            }
            catch
            {
                throw new Exception("数据类型[" + value.GetType().Name + "]转换到数据类型[" + typeof(T).Name + "]出错!");
            }
            return (T)obj;
        }
        public static bool IsNotNull(this object value)
        {
            return !IsNull(value);
        }
        /// <summary>
        /// 判断对象是否为空； （数值类型为判断是否等于最小值。）
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsNull(this object value)
        {
            if (Convert.IsDBNull(value))
                return true;
            if (value == null)
                return true;
            if (value is string)
            {
                return (value as string).IsNull();
            }
            else if (value is int)
            {
                return ((int)value == int.MinValue);
            }
            else if (value is Int32)
            {
                return ((Int32)value == Int32.MinValue);
            }
            else if (value is Int64)
            {
                return ((Int64)value == Int64.MinValue);
            }
            else if (value is long)
            {
                return ((long)value).IsNull();
            }
            else if (value is decimal)
            {
                return ((decimal)value).IsNull();
            }
            else if (value is double)
            {
                return ((double)value).IsNull();
            }
            else if (value is DateTime)
            {
                return ((DateTime)value).IsNull();
            }
            else if (value is System.Data.DataSet)
            {
                return (value as System.Data.DataSet).IsNull();
            }
            else
            {
                throw new Exception("未知数据类型[" + value.GetType().Name + "]");
            }
        }
        private static bool IsNull(this string value)
        {
            if (string.IsNullOrEmpty(value))
                return true;
            return false;
        }
        private static bool IsNull(this long value)
        {
            if (value == _NULL_LONG)
                return true;
            return false;
        }
        private static bool IsNull(this decimal value)
        {
            if (value == _NULL_DECIMAL)
                return true;
            return false;
        }
        private static bool IsNull(this double value)
        {
            if (value == _NULL_DOUBLE)
                return true;
            return false;
        }
        private static bool IsNull(this DateTime value)
        {
            if (value == DateTime.MinValue)
                return true;
            return false;
        }
        private static bool IsNull(this System.Data.DataSet value)
        {
            if (value == null || value.Tables.Count == 0)
                return true;
            return false;
        }
        //public static void SetNull(this string value)
        //{
        //    value = string.Empty;
        //}
        //public static void SetNull(this long value)
        //{
        //    value = 0;
        //}
        //public static void SetNull(this int value)
        //{
        //    value = 0;
        //}
        //public static void SetNull(this double value)
        //{
        //    value = 0;
        //}
        //public static void SetNull(this decimal value)
        //{
        //    value = 0;
        //}
        //public static void SetNull(this DateTime value)
        //{
        //    value = DateTime.MinValue;
        //}
        /// <summary>
        /// 将数组中的数据转化为string类型，用分隔符","隔开。
        /// </summary>
        /// <param name="value">需要转化的数组</param>
        /// <returns>转化后的字符串</returns>
        public static string ArrayToString(this object[] value)
        {
            if (value == null || value.Length == 0)
                return string.Empty;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < value.Length; i++)
            {
                sb.Append(value);
                if (i < value.Length - 1)
                    sb.Append(',');
            }
            return sb.ToString();
        }
        #region 四舍五入
        /// <summary>
        /// Double值类型的四舍五入运算(利用ToString)
        /// 用法：a = MathMethod.DoubleRoundFormat(a, "##################.##");
        /// </summary>
        /// <param name="value">计算前的值</param>
        /// <param name="formatString">得到的值的格式：要保留的小数位等</param>
        /// <returns>计算后的值</returns>
        public static double DoubleRound(this double value, string formatString)
        {
            if (string.IsNullOrEmpty(formatString))
            {
                formatString = "##################.##";
            }
            string rtnValue;
            rtnValue = value.ToString(formatString);
            if (rtnValue.IsNull())
            {
                rtnValue = "0";
            };
            return Convert.ToDouble(rtnValue);
        }
        /// <summary>
        /// Double值类型的四舍五入运算(利用小数位)
        /// </summary>
        /// <param name="value">计算前的值</param>
        /// <param name="decimalPlace">几位小数</param>
        /// <returns>计算后的值</returns>
        public static double DoubleRound(this double value, int decimalPlace)
        {
            string formatString = "#.";
            for (int i = 0; i < decimalPlace; i++)
            {
                formatString += "#";
            }
            string rtnValue;
            rtnValue = value.ToString(formatString);
            if (rtnValue.IsNull())
            {
                rtnValue = "0";
            }
            return Convert.ToDouble(rtnValue);
        }
        /// <summary>
        /// Double值类型的四舍五入运算(2位小数)，一般用于统一金额运算(利用ToString)
        /// 用法：a = MathMethod.DoubleRoundFormat(a);
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static double DoubleRound(this double value)
        {
            return DoubleRound(value, "##################.##");
        }
        /// <summary>
        /// 计算从datatable中取得DOUBLE数据的四舍五入
        /// </summary>
        /// <param name="value">计算前的值</param>
        /// <param name="formatString">得到的值的格式：要保留的小数位等</param>
        /// <returns>计算后的值</returns>
        public static double DoubleRound(this object value, string formatString)
        {
            double rtn;
            rtn = value.To<double>();
            return DoubleRound(rtn, formatString);
        }
        /// <summary>
        /// 计算从datatable中取得DOUBLE数据的四舍五入
        /// </summary>
        /// <param name="value">计算前的值</param>
        /// <param name="decimalPlace">几位小数</param>
        /// <returns>计算后的值</returns>
        public static double DoubleRound(this object value, int decimalPlace)
        {
            double rtn;
            rtn = value.To<double>();
            return DoubleRound(rtn, decimalPlace);
        }
        /// <summary>
        /// 计算从datatable中取得DOUBLE数据的四舍五入
        /// </summary>
        /// <param name="value">计算前的值</param>
        /// <returns>计算后的值</returns>
        public static double DoubleRound(this object value)
        {
            double rtn;
            rtn = value.To<double>();
            return DoubleRound(rtn, "##################.##");
        }
        #endregion 四舍五入
    }
}