﻿using System;
namespace DotNet.Utilities
{
    public class DateFormat
    {
        /// <summary>
        /// 返回每月的第一天和最后一天
        /// </summary>
        /// <param name="month"></param>
        /// <param name="firstDay"></param>
        /// <param name="lastDay"></param>
        public static void ReturnDateFormat(int month, out string firstDay, out string lastDay)
        {
            int year = DateTime.Now.Year + month / 12;
            if (month != 12)
            {
                month = month % 12;
            }
            switch (month)
            {
                case 1:
                    firstDay = DateTime.Now.ToString(year + "-0" + month + "-01");
                    lastDay = DateTime.Now.ToString(year + "-0" + month + "-31");
                    break;
                case 2:
                    firstDay = DateTime.Now.ToString(year + "-0" + month + "-01");
                    if (DateTime.IsLeapYear(DateTime.Now.Year))
                        lastDay = DateTime.Now.ToString(year + "-0" + month + "-29");
                    else
                        lastDay = DateTime.Now.ToString(year + "-0" + month + "-28");
                    break;
                case 3:
                    firstDay = DateTime.Now.ToString(year + "-0" + month + "-01");
                    lastDay = DateTime.Now.ToString("yyyy-0" + month + "-31");
                    break;
                case 4:
                    firstDay = DateTime.Now.ToString(year + "-0" + month + "-01");
                    lastDay = DateTime.Now.ToString(year + "-0" + month + "-30");
                    break;
                case 5:
                    firstDay = DateTime.Now.ToString(year + "-0" + month + "-01");
                    lastDay = DateTime.Now.ToString(year + "-0" + month + "-31");
                    break;
                case 6:
                    firstDay = DateTime.Now.ToString(year + "-0" + month + "-01");
                    lastDay = DateTime.Now.ToString(year + "-0" + month + "-30");
                    break;
                case 7:
                    firstDay = DateTime.Now.ToString(year + "-0" + month + "-01");
                    lastDay = DateTime.Now.ToString(year + "-0" + month + "-31");
                    break;
                case 8:
                    firstDay = DateTime.Now.ToString(year + "-0" + month + "-01");
                    lastDay = DateTime.Now.ToString(year + "-0" + month + "-31");
                    break;
                case 9:
                    firstDay = DateTime.Now.ToString(year + "-0" + month + "-01");
                    lastDay = DateTime.Now.ToString(year + "-0" + month + "-30");
                    break;
                case 10:
                    firstDay = DateTime.Now.ToString(year + "-" + month + "-01");
                    lastDay = DateTime.Now.ToString(year + "-" + month + "-31");
                    break;
                case 11:
                    firstDay = DateTime.Now.ToString(year + "-" + month + "-01");
                    lastDay = DateTime.Now.ToString(year + "-" + month + "-30");
                    break;
                default:
                    firstDay = DateTime.Now.ToString(year + "-" + month + "-01");
                    lastDay = DateTime.Now.ToString(year + "-" + month + "-31");
                    break;
            }
        }
        #region Rss日期时间转换，将时间全部转换为GMT时间
        /// <summary>
        /// Rss日期时间转换，将时间全部转换为GMT时间
        /// </summary>
        /// <param name="strDateTime">Rss中读取的时间</param>
        /// <returns>处理后的标准时间格式</returns>
        public static string dateConvert(string strDateTime)
        {
            strDateTime = strDateTime.Replace("+0000", "GMT");
            strDateTime = strDateTime.Replace("+0100", "GMT");
            strDateTime = strDateTime.Replace("+0200", "GMT");
            strDateTime = strDateTime.Replace("+0300", "GMT");
            strDateTime = strDateTime.Replace("+0400", "GMT");
            strDateTime = strDateTime.Replace("+0500", "GMT");
            strDateTime = strDateTime.Replace("+0600", "GMT");
            strDateTime = strDateTime.Replace("+0700", "GMT");
            strDateTime = strDateTime.Replace("+0800", "GMT");
            strDateTime = strDateTime.Replace("-0000", "GMT");
            strDateTime = strDateTime.Replace("-0100", "GMT");
            strDateTime = strDateTime.Replace("-0200", "GMT");
            strDateTime = strDateTime.Replace("-0300", "GMT");
            strDateTime = strDateTime.Replace("-0400", "GMT");
            strDateTime = strDateTime.Replace("-0500", "GMT");
            strDateTime = strDateTime.Replace("-0600", "GMT");
            strDateTime = strDateTime.Replace("-0700", "GMT");
            strDateTime = strDateTime.Replace("-0800", "GMT");
            DateTime dt = DateTime.Parse(strDateTime, null, System.Globalization.DateTimeStyles.AdjustToUniversal);
            return dt.ToString();
        }
        #endregion Rss日期时间转换，将时间全部转换为GMT时间
    }
}