﻿
namespace KenceryCommonMethod
{
    /// 成功与否的枚举状态
    /// <auther>
    ///     <name>Kencery</name>
    ///     <date>2015-6-11</date>
    /// </auther>
    public enum Successed
    {
        /// 操作成功
        Ok = 200,       
        /// 查询结果为空        
        Empty = 201,
        /// 操作失败
        Error = 201
    }
    /// 系统错误信息
    /// <auther>
    ///     <name>Kencery</name>
    ///     <date>2015-6-11</date>
    /// </auther>
    public enum System
    {
        /// 内部服务器错误
        InternalServerError = 1000,
        /// 请求参数错误
        InvalidRequest = 1002
    }
    /// 系统校验信息
    /// <auther>
    ///     <name>Kencery</name>
    ///     <date>2015-6-11</date>
    /// </auther>
    public enum Validate
    {
        /// 手机号不能为空
        EmptyTelephoneCode = 40000,
        /// Email不能为空
        EmptyEmailCode = 40001,
        /// 验证码不能为空
        EmptyAuthCode = 40002,
        /// 密码不能为空
        EmptyPasswordCode = 40003,
        /// 旧密码不能为空
        EmptyOldPasswordCode = 40004,
        /// 新密码不能为空
        EmptyNewPasswordCOde = 40005,
        /// 两次输入的密码不一致
        InconFormityPasswordCode = 40006,
        /// 密码设置错误
        SetPasswordError = 40007,
        /// 请输入正确的手机号
        InvalidTelephone = 50000,
        /// 请输入正确的邮箱
        InvalidEmail = 50001,
        /// 请输入正确的手机号或者Email地址
        InvalidEmailOrTelePhone = 50002,
        /// 无效的用户信息
        InvalidUserId = 50003,
        /// 未找到要删除的信息
        NotFoundDeleteInfo = 30000,
        /// 未找到要修改的信息
        NotFoundUpdateInfo = 30001,
        /// 手机号码已经存在
        TelephoneRegistered = 60000,
        /// Email已经存在
        EmailRegistered = 60001,
        /// 用户已经存在
        UserRegistered = 60002,
        /// 用户尚未登录
        UserNotLogin = 7000,
        /// 用户尚未注册
        UserUnregistered = 7001,
        /// 无权限登录
        NoPermissionToLogin = 7002,
        /// 验证码错误，请重新输入
        VerificationCodeErrorPleaseEnterAgain = 8000,
        /// 验证码发送失败
        SendAuthCodeFail = 8001,
        /// 验证码发送过于频繁，请稍后重试
        FrequentSendAuthCode = 8002
    }
    /// 第三方插件错误提示信息
    /// <auther>
    ///     <name>Kencery</name>
    ///     <date>2015-6-11</date>
    /// </auther>
    public enum PlugIn
    {
        /// 百度服务返回结果无效
        BaiDuServiceError = 10001,
        /// 阿里巴巴服务返回结果无效
        AliPayServiceError = 10002,
        /// 微信服务返回结果无效
        WechatServiceError = 10003
    }
}