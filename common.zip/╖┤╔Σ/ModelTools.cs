﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Reflection;
namespace CRM.Action.tool
{
    public class ModelTools
    {
        public static void Form2Model(NameValueCollection Form, Object obj)
        {
            //得到type
            Type type = obj.GetType();
            //得到所有set属性
            PropertyInfo[] pis = type.GetProperties(BindingFlags.SetProperty | BindingFlags.Public | BindingFlags.Instance);
            //循环数组里面每一个PropertyInfo
            foreach (PropertyInfo pi in pis)
            {
                //得到属性名称
                string name = pi.Name;
                //根据属性名称去表单里面取值  表单的name与属性名称必须一致
                var value = Form[name];
                //判断这个是否为空
                if (value != null && !"".Equals(value))
                {
                    //调用SetValue设置值
                    pi.SetValue(obj, Convert.ChangeType(value, pi.PropertyType));
                }
            }
        }
    }
}