﻿/// <summary>
/// 将对象转换为Int32类型
/// </summary>
/// <param name="strValue">要转换的字符串</param>
/// <param name="defValue">缺省值</param>
/// <returns>转换后的int类型结果</returns>
public static int ObjectToInt(object expression)
{
    return ObjectToInt(expression, 0);
}
/// <summary>
/// 将对象转换为Int32类型
/// </summary>
/// <param name="strValue">要转换的字符串</param>
/// <param name="defValue">缺省值</param>
/// <returns>转换后的int类型结果</returns>
public static int ObjectToInt(object expression, int defValue)
{
    if (expression != null)
        return StrToInt(expression.ToString(), defValue);
    return defValue;
}
/// <summary>
/// 将对象转换为Int32类型,转换失败返回0
/// </summary>
/// <param name="str">要转换的字符串</param>
/// <returns>转换后的int类型结果</returns>
public static int StrToInt(string str)
{
    return StrToInt(str, 0);
}
/// <summary>
/// 将对象转换为Int32类型
/// </summary>
/// <param name="str">要转换的字符串</param>
/// <param name="defValue">缺省值</param>
/// <returns>转换后的int类型结果</returns>
public static int StrToInt(string str, int defValue)
{
    if (string.IsNullOrEmpty(str) || str.Trim().Length >= 11 || !Regex.IsMatch(str.Trim(), @"^([-]|[0-9])[0-9]*(\.\w*)?$"))
        return defValue;
    int rv;
    if (Int32.TryParse(str, out rv))
        return rv;
    return Convert.ToInt32(StrToFloat(str, defValue));
}
/// <summary>
/// string型转换为float型
/// </summary>
/// <param name="strValue">要转换的字符串</param>
/// <param name="defValue">缺省值</param>
/// <returns>转换后的int类型结果</returns>
public static float StrToFloat(object strValue, float defValue)
{
    if ((strValue == null))
        return defValue;
    return StrToFloat(strValue.ToString(), defValue);
}
/// <summary>
/// string型转换为float型
/// </summary>
/// <param name="strValue">要转换的字符串</param>
/// <param name="defValue">缺省值</param>
/// <returns>转换后的int类型结果</returns>
public static float ObjectToFloat(object strValue, float defValue)
{
    if ((strValue == null))
        return defValue;
    return StrToFloat(strValue.ToString(), defValue);
}
/// <summary>
/// string型转换为float型
/// </summary>
/// <param name="strValue">要转换的字符串</param>
/// <param name="defValue">缺省值</param>
/// <returns>转换后的int类型结果</returns>
public static float ObjectToFloat(object strValue)
{
    return ObjectToFloat(strValue.ToString(), 0);
}
/// <summary>
/// string型转换为float型
/// </summary>
/// <param name="strValue">要转换的字符串</param>
/// <returns>转换后的int类型结果</returns>
public static float StrToFloat(string strValue)
{
    if ((strValue == null))
        return 0;
    return StrToFloat(strValue.ToString(), 0);
}
/// <summary>
/// string型转换为float型
/// </summary>
/// <param name="strValue">要转换的字符串</param>
/// <param name="defValue">缺省值</param>
/// <returns>转换后的int类型结果</returns>
public static float StrToFloat(string strValue, float defValue)
{
    if ((strValue == null) || (strValue.Length > 10))
        return defValue;
    float intValue = defValue;
    if (strValue != null)
    {
        bool IsFloat = Regex.IsMatch(strValue, @"^([-]|[0-9])[0-9]*(\.\w*)?$");
        if (IsFloat)
            float.TryParse(strValue, out intValue);
    }
    return intValue;
}
/// <summary>
/// 将对象转换为日期时间类型
/// </summary>
/// <param name="str">要转换的字符串</param>
/// <param name="defValue">缺省值</param>
/// <returns>转换后的int类型结果</returns>
public static DateTime StrToDateTime(string str, DateTime defValue)
{
    if (!string.IsNullOrEmpty(str))
    {
        DateTime dateTime;
        if (DateTime.TryParse(str, out dateTime))
            return dateTime;
    }
    return defValue;
}
/// <summary>
/// 将对象转换为日期时间类型
/// </summary>
/// <param name="str">要转换的字符串</param>
/// <returns>转换后的int类型结果</returns>
public static DateTime StrToDateTime(string str)
{
    return StrToDateTime(str, DateTime.Now);
}
/// <summary>
/// 将对象转换为日期时间类型
/// </summary>
/// <param name="obj">要转换的对象</param>
/// <returns>转换后的int类型结果</returns>
public static DateTime ObjectToDateTime(object obj)
{
    return StrToDateTime(obj.ToString());
}
/// <summary>
/// 将对象转换为日期时间类型
/// </summary>
/// <param name="obj">要转换的对象</param>
/// <param name="defValue">缺省值</param>
/// <returns>转换后的int类型结果</returns>
public static DateTime ObjectToDateTime(object obj, DateTime defValue)
{
    return StrToDateTime(obj.ToString(), defValue);
}
/// <summary>
/// 替换回车换行符为html换行符
/// </summary>
public static string StrFormat(string str)
{
    string str2;
    if (str == null)
    {
        str2 = "";
    }
    else
    {
        str = str.Replace("\r\n", "<br />");
        str = str.Replace("\n", "<br />");
        str2 = str;
    }
    return str2;
}
/// <summary>
/// 转换为简体中文
/// </summary>
public static string ToSChinese(string str)
{
    return Strings.StrConv(str, VbStrConv.SimplifiedChinese, 0);
}
/// <summary>
/// 转换为繁体中文
/// </summary>
public static string ToTChinese(string str)
{
    return Strings.StrConv(str, VbStrConv.TraditionalChinese, 0);
}
/// <summary>
/// 清除字符串数组中的重复项
/// </summary>
/// <param name="strArray">字符串数组</param>
/// <param name="maxElementLength">字符串数组中单个元素的最大长度</param>
/// <returns></returns>
public static string[] DistinctStringArray(string[] strArray, int maxElementLength)
{
    Hashtable h = new Hashtable();
    foreach (string s in strArray)
    {
        string k = s;
        if (maxElementLength > 0 && k.Length > maxElementLength)
        {
            k = k.Substring(0, maxElementLength);
        }
        h[k.Trim()] = s;
    }
    string[] result = new string[h.Count];
    h.Keys.CopyTo(result, 0);
    return result;
}
/// <summary>
/// 清除字符串数组中的重复项
/// </summary>
/// <param name="strArray">字符串数组</param>
/// <returns></returns>
public static string[] DistinctStringArray(string[] strArray)
{
    return DistinctStringArray(strArray, 0);
}