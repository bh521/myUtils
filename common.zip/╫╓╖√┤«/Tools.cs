﻿
namespace Core.Common
{
    /// <summary>
    /// 共用工具类
    /// </summary>
    public static class Tools
    {
        public static string switch_riddle(string s_ch)//解密
        {
            string s_out, s_temp, temp;
            int i_len = s_ch.Length;
            if (i_len == 0 || s_ch == "")
            {
                s_out = "0";
            }
            temp = "";
            s_temp = "";
            s_out = "";
            for (int i = 0; i <= i_len - 1; i++)
            {
                temp = s_ch.Substring(i, 1);
                switch (temp)
                {
                    case "a":
                        s_temp = "1010";
                        break;
                    case "b":
                        s_temp = "1011";
                        break;
                    case "c":
                        s_temp = "1100";
                        break;
                    case "d":
                        s_temp = "1101";
                        break;
                    case "e":
                        s_temp = "1110";
                        break;
                    case "f":
                        s_temp = "1111";
                        break;
                    case "0":
                        s_temp = "0000";
                        break;
                    case "1":
                        s_temp = "0001";
                        break;
                    case "2":
                        s_temp = "0010";
                        break;
                    case "3":
                        s_temp = "0011";
                        break;
                    case "4":
                        s_temp = "0100";
                        break;
                    case "5":
                        s_temp = "0101";
                        break;
                    case "6":
                        s_temp = "0110";
                        break;
                    case "7":
                        s_temp = "0111";
                        break;
                    case "8":
                        s_temp = "1000";
                        break;
                    case "9":
                        s_temp = "1001";
                        break;
                    default:
                        s_temp = "0000";
                        break;
                }
                s_out = s_out + s_temp;
                s_temp = "";
            }
            return s_out;
        }
       
        #region 用户权限的加密过程
        public static string switch_encrypt(string s_ch)
        {
            string s_out, s_temp, temp;
            int i_len = 64;
            if (i_len == 0 || s_ch == "")
            {
                s_out = "0000";
            }
            temp = "";
            s_temp = "";
            s_out = "";
            for (int i = 0; i <= i_len - 1; i = i + 4)
            {
                temp = s_ch.Substring(i, 4);
                switch (temp)
                {
                    case "1010":
                        s_temp = "a";
                        break;
                    case "1011":
                        s_temp = "b";
                        break;
                    case "1100":
                        s_temp = "c";
                        break;
                    case "1101":
                        s_temp = "d";
                        break;
                    case "1110":
                        s_temp = "e";
                        break;
                    case "1111":
                        s_temp = "f";
                        break;
                    case "0000":
                        s_temp = "0";
                        break;
                    case "0001":
                        s_temp = "1";
                        break;
                    case "0010":
                        s_temp = "2";
                        break;
                    case "0011":
                        s_temp = "3";
                        break;
                    case "0100":
                        s_temp = "4";
                        break;
                    case "0101":
                        s_temp = "5";
                        break;
                    case "0110":
                        s_temp = "6";
                        break;
                    case "0111":
                        s_temp = "7";
                        break;
                    case "1000":
                        s_temp = "8";
                        break;
                    case "1001":
                        s_temp = "9";
                        break;
                    default:
                        s_temp = "0";
                        break;
                }
                s_out = s_out + s_temp;
                s_temp = "";
            }
            return s_out;
        }//加密
        #endregion 用户权限的加密过程
        #region 访问权限
        public static bool CheckTrue(string s_admin, int a)
        {
            string s_temp = "";
            s_temp = s_admin.Substring(a - 1, 1);   //s_admin为全局变量
            if (s_temp == "" || s_temp == "1")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion 访问权限
        #region 用户名密码格式
        /// <summary>
        /// 返回字符串真实长度, 1个汉字长度为2
        /// </summary>
        /// <returns>字符长度</returns>
        public static int GetStringLength(string stringValue)
        {
            return Encoding.Default.GetBytes(stringValue).Length;
        }
        /// <summary>
        /// 检测用户名格式是否有效
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public static bool IsValidUserName(string userName)
        {
            int userNameLength = GetStringLength(userName);
            if (userNameLength >= 4 && userNameLength <= 20 && Regex.IsMatch(userName, @"^([\u4e00-\u9fa5A-Za-z_0-9]{0,})$"))
            {   // 判断用户名的长度（4-20个字符）及内容（只能是汉字、字母、下划线、数字）是否合法
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 密码有效性
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static bool IsValidPassword(string password)
        {
            return Regex.IsMatch(password, @"^[A-Za-z_0-9]{6,16}$");
        }
        #endregion 用户名密码格式
        #region 是否由特定字符组成
        public static bool isContainSameChar(string strInput)
        {
            string charInput = string.Empty;
            if (!string.IsNullOrEmpty(strInput))
            {
                charInput = strInput.Substring(0, 1);
            }
            return isContainSameChar(strInput, charInput, strInput.Length);
        }
        public static bool isContainSameChar(string strInput, string charInput, int lenInput)
        {
            if (string.IsNullOrEmpty(charInput))
            {
                return false;
            }
            else
            {
                Regex RegNumber = new Regex(string.Format("^([{0}])+$", charInput));
                //Regex RegNumber = new Regex(string.Format("^([{0}]{{1}})+$", charInput,lenInput));
                Match m = RegNumber.Match(strInput);
                return m.Success;
            }
        }
        #endregion 是否由特定字符组成
        /// <summary>
        /// 错误消息输出
        /// </summary>
        private static void page_Error(object sender, EventArgs e)
        {
            Page page1 = (Page)sender;
            Exception exception1 = page1.Server.GetLastError();
            StringBuilder builder1 = new StringBuilder();
            builder1.Append("<div style=\"font-size:10pt;font-family:verdana;line-height:150%;\">");
            builder1.AppendFormat("<strong>\u9519\u8bef\u6d88\u606f\uff1a</strong>{0} \n", exception1.Message);
            builder1.AppendFormat("<strong>\u5bfc\u81f4\u9519\u8bef\u7684\u5e94\u7528\u7a0b\u5e8f\u6216\u5bf9\u8c61\u7684\u540d\u79f0</strong>\uff1a{0} \n", exception1.Source);
            builder1.AppendFormat("<div style=\"background-color:yellow;color:red;padding:12px;\"><strong>\u5806\u6808\u5185\u5bb9</strong>\uff1a{0} </div>\n", exception1.StackTrace);
            builder1.AppendFormat("<strong>\u5f15\u53d1\u5f02\u5e38\u7684\u65b9\u6cd5</strong>\uff1a{0} \n", exception1.TargetSite);
            builder1.AppendFormat("<strong>\u9519\u8bef\u9875\u9762</strong>\uff1a{0} \n", page1.Request.RawUrl);
            builder1.Append("</div>");
            page1.Server.ClearError();
            page1.Response.Write(builder1.ToString().Replace("\n", "<br/>"));
        }
        /// <summary>
        /// MyMethod()
        /// </summary>
        public static void RegisterOnlineDebug(Page page)
        {
            Uri uri1 = page.Request.UrlReferrer;
            if (((page.Request["DEBUG"] != null) && (page.Request["DEBUG"] == "true")) ||
                ((uri1 != null) && (uri1.ToString().IndexOf("DEBUG=") != -1)))
            {
                page.Error += new EventHandler(page_Error);
            }
        }
        #region 字符文本类
        /// <summary>
        /// HTML代码生成
        /// </summary>
        /// <param name="dTab">数据表格源</param>
        /// <param name="objModel">模版数据(Item,AlterItem,LiteralCount,Lieteral,Header,Footer)</param>
        /// <returns>根据相应Repeater模版生成的字符集</returns>
        /// <remarks>ST:ToPractice More, Fixed 2006-4-4</remarks>
        public static string GeneralHtmlBind(DataTable dTab, params string[] objModel)
        {
            StringBuilder sb = new StringBuilder(5000);
            DataRow dRow = null;
            int k = 1;
            if (dTab != null)
            {
                for (int i = 0; i < dTab.Rows.Count; i++)
                {
                    dRow = dTab.Rows[i];
                    if (k == 1 && objModel.Length > 4)
                    {
                        sb.Append(String.Format(objModel[4] + "\n", dRow.ItemArray));
                    }
                    if (objModel.Length > 1 && objModel[1] != string.Empty && k % 2 == 0)
                    {
                        sb.Append(String.Format(objModel[1].Replace("$", k.ToString()), dRow.ItemArray));
                    }
                    else
                    {
                        sb.Append(String.Format(objModel[0].Replace("$", k.ToString()), dRow.ItemArray));
                    }
                    if (objModel.Length > 3 && objModel[3] != string.Empty && IsNumerical(objModel[2]))
                    {
                        if (k % int.Parse(objModel[2]) == 0 && k < dTab.Rows.Count)
                        {
                            sb.Append(objModel[3]);
                        }
                    }
                    if (k == dTab.Rows.Count && objModel.Length > 5)
                    {
                        sb.Append(String.Format(objModel[5] + "\n", dRow.ItemArray));
                    }
                    k++;
                }
                dTab.Dispose();
            }
            return sb.ToString();
        }
        /// <summary>
        /// 判断输入对象是否为数字类型
        /// </summary>
        /// <param name="strInput">输入对象</param>
        /// <returns>是否为不含小数点的数字类型</returns>
        private static bool IsNumerical(object strInput)
        {
            if (strInput == null)
            {
                return false;
            }
            bool bValue = true;
            string strCheck = strInput.ToString();
            if (strCheck.Length == 0) return false;
            for (int i = 0; i < strCheck.Length; i++)
            {
                if (!char.IsDigit(strCheck, i))
                {
                    bValue = false;
                    break;
                }
            }
            return bValue;
        }
        /// <summary>
        /// 获取定长像素的网页片段，多余部分用省略号代替。(ellipsis)
        /// </summary>
        /// <param name="htmlText">片段内容</param>
        /// <param name="width">片段长度</param>
        /// <returns>相关属性样式的DIV片段</returns>
        /// <remarks>2008-1-29 by Ridge Wong</remarks>
        public static string GetFixedDivEllipsis(string htmlText, int width)
        {
            return string.Format("<div style=\"width:{0}px;overflow:hidden;float:left;text-overflow:ellipsis;white-space:nowrap;\">{1}</div>",
                width, htmlText);
        }
        /// <summary>
        /// 返回指定数据的重复次数
        /// </summary>
        /// <param name="objInt">int型数据</param>
        /// <param name="strRepeat">重复的字符片段</param>
        /// <returns>Example:ReplicateObject(5,"*")="*****"</returns>
        public static string ReplicateObject(object objInt, string strRepeat)
        {
            string strRet = string.Empty;
            if (objInt != null)
            {
                int Count = Convert.ToInt32(objInt);
                strRet = (Count > 0) ? (new string('*', Count)) : "";
            }
            else
            {
                strRet = "";
            }
            return strRet.Replace("*", strRepeat);
        }
        /// <summary>
        /// 去掉小数位后无意义的0，如21.50结尾为21.5。
        /// </summary>
        /// <param name="pointNum">金额绑定对象</param>
        /// <returns>相关小数点金额</returns>
        public static string StripZeroEnd(object pointNum)
        {
            if (pointNum == null) { return "0"; }
            return Regex.Replace(pointNum.ToString(), @"(\.)?0{1,}$", "");
        }
        #endregion 字符文本类
              #region 使用正则表达式删除用户输入中的html内容
        /// <summary>
        /// 使用正则表达式删除用户输入中的html内容
        /// </summary>
        /// <param name="text">输入内容</param>
        /// <returns>清理后的文本</returns>
        public static string clearHtml(string text)
        {
            string pattern;
            if (text.Length == 0)
                return text;
            pattern = @"(<[a-zA-Z].*?>)|(<[\/][a-zA-Z].*?>)";
            text = Regex.Replace(text, pattern, String.Empty, RegexOptions.IgnoreCase);
            text = text.Replace("<", "<");
            text = text.Replace(">", ">");
            return text;
        }
        public static string ClearHtml(string Html)
        {
            if (Html == string.Empty || string.IsNullOrEmpty(Html))
                return "";
            Regex RegexFrame = new Regex(@"<\/*[^<>]*>", RegexOptions.IgnoreCase);
            return RegexFrame.Replace(Html, string.Empty).Replace("&nbsp;", string.Empty);
        }
        #endregion 使用正则表达式删除用户输入中的html内容
        #region 使用正则表达式删除用户输入中的JS脚本内容
        /// <summary>
        /// 使用正则表达式删除用户输入中的JS脚本内容
        /// </summary>
        /// <param name="text">输入内容</param>
        /// <returns>清理后的文本</returns>
        public static string clearScript(string text)
        {
            string pattern;
            if (text.Length == 0)
                return text;
            pattern = @"(?i)<script([^>])*>(\w|\W)*</script([^>])*>";
            text = Regex.Replace(text, pattern, String.Empty, RegexOptions.IgnoreCase);
            pattern = @"<script([^>])*>";
            text = Regex.Replace(text, pattern, String.Empty, RegexOptions.IgnoreCase);
            pattern = @"</script>";
            text = Regex.Replace(text, pattern, String.Empty, RegexOptions.IgnoreCase);
            return text;
        }
        #endregion 使用正则表达式删除用户输入中的JS脚本内容
        #region 过滤SQL,所有涉及到输入的用户直接输入的地方都要使用
        /// <summary>
        /// 过滤SQL,所有涉及到输入的用户直接输入的地方都要使用。
        /// </summary>
        /// <param name="text">输入内容</param>
        /// <returns>过滤后的文本</returns>
        public static string filterSQL(string text)
        {
            text = text.Replace("'", "''");
            text = text.Replace("{", "{");
            text = text.Replace("}", "}");
            return text;
        }
        #endregion 过滤SQL,所有涉及到输入的用户直接输入的地方都要使用
        #region 过滤SQL,将SQL字符串里面的(')转换成('')，再在字符串的两边加上(')
        /// <summary>
        /// 将SQL字符串里面的(')转换成('')，再在字符串的两边加上(')。
        /// </summary>
        /// <param name="text">输入内容</param>
        /// <returns>过滤后的文本</returns>
        public static String GetQuotedString(String text)
        {
            return ("'" + filterSQL(text) + "'");
        }
        #endregion 过滤SQL,将SQL字符串里面的(')转换成('')，再在字符串的两边加上(')
        #region 提取中文首字母
        #region 获取中文字首字拼写
        /// <summary>
        /// 获取中文字首字拼写
        /// </summary>
        /// <param name="chinese"></param>
        /// <returns></returns>
        static public string GetChineseSpell(string strText)
        {
            int len = strText.Length;
            string myStr = "";
            for (int i = 0; i < len; i++)
            {
                myStr += getSpell(strText.Substring(i, 1));
            }
            return myStr;
        }
        #endregion 获取中文字首字拼写
        #region 获取单个字首字母 (GB2312)
        /// <summary>
        /// 获取单个字首字母 (GB2312)
        /// </summary>
        /// <param name="cnChar"></param>
        /// <returns></returns>
        static public string getSpell(string cnChar)
        {
            byte[] arrCN = Encoding.Default.GetBytes(cnChar);
            if (arrCN.Length > 1)
            {
                int area = (short)arrCN[0];
                int pos = (short)arrCN[1];
                int code = (area << 8) + pos;
                int[] areacode = { 45217, 45253, 45761, 46318, 46826, 47010, 47297, 47614, 48119, 48119, 49062, 49324, 49896, 50371, 50614, 50622, 50906, 51387, 51446, 52218, 52698, 52698, 52698, 52980, 53689, 54481 };
                for (int i = 0; i < 26; i++)
                {
                    int max = 55290;
                    if (i != 25) max = areacode[i + 1];
                    if (areacode[i] <= code && code < max)
                    {
                        return Encoding.Default.GetString(new byte[] { (byte)(97 + i) });
                    }
                }
                return "*";
            }
            else return cnChar;
        }
        #endregion 获取单个字首字母 (GB2312)
        #endregion 提取中文首字母
        #region AjaxPro使用的分页方法
        /// <summary>
        /// 使用AjaxPro时候使用的方法
        /// </summary>
        /// <param name="pageIndex">第几页</param>
        /// <param name="pageIndex">总共多少页</param>
        /// <param name="pageIndex">当前页条数</param>
        /// <param name="pageIndex">总条数</param>
        /// <returns>分页导航</returns>
        public static string AjaxPages(int pageIndex, int pageCount, int roscount, int counts)
        {
            StringBuilder text = new StringBuilder();
            //新的分页
            text.Append("<br><TABLE class='tableborder' cellSpacing='1' cellPadding='3' width='98%'  border='0' align='center'>");
            text.Append("<td align='left' width='250px'>第" + pageIndex + "页/总" + pageCount + "页　本页" + roscount + "条/总" + counts + "条 </td>");
            text.Append("<td align='left' width='40px'><a href='javascript:JumpPage(1)'>首页</a></td>");
            if (pageIndex < pageCount)
            {
                text.Append("<td align='left' width='40px'><a href='javascript:JumpPage(" + (pageIndex + 1) + ")'>下一页</a></td>");
            }
            else
            {
                text.Append("<td align='left' width='40px'>下一页</a></td>");
            }
            if (pageIndex > 1)
            {
                text.Append("<td align='left' width='40px'><a href='javascript:JumpPage(" + (pageIndex - 1) + ")'>上一页</a></td>");
            }
            else
            {
                text.Append("<td align='left' width='40px'>上一页</a></td>");
            }
            text.Append("<td align='left' width='40px'><a href='javascript:JumpPage(" + pageCount + ")'>尾页</a><td>");
            int BasePage = (pageIndex / 10) * 10;
            if (BasePage > 0)
            {
                text.Append("<td align='left' width='20px'><a href='javascript:JumpPage(" + (BasePage - 9) + ")'>&lt;&lt;</a></td>");
            }
            for (int j = 1; j < 11; j++)
            {
                int PageNumber = BasePage + j;
                if (PageNumber > pageCount)
                {
                    break;
                }
                if (PageNumber == Convert.ToInt32(pageIndex))
                {
                    text.Append("<td align='left' width='20px'><font color='#FF0000'>" + PageNumber + "</font></td>");
                }
                else
                {
                    text.Append("<td align='left' width='20px'><a href='javascript:JumpPage(" + PageNumber + ")'>" + PageNumber + "</a></td>");
                }
            }
            if (pageCount - 1 > BasePage)
            {
                text.Append("<td align='left' width='20px'><a href='javascript:JumpPage(" + (BasePage + 11) + ")'>&gt;&gt;</a></td>");
            }
            text.Append("</table>");
            return text.ToString();
        }
        #endregion AjaxPro使用的分页方法
        #region 替换XML文档不接受的字符
        /// <summary>
        /// 替换XML文档不接受的字符
        /// </summary>
        /// <param name="input">传入值</param>
        /// <returns>替换后的字符</returns>
        public static string formatForXML(object input)
        {
            string str = input.ToString();
            //替换XML文档不接受的字符
            str = str.Replace(" ", " ");
            str = str.Replace("&", "&");
            str = str.Replace("\"", "''");
            str = str.Replace("'", "&apos;");
            return str;
        }
        #endregion 替换XML文档不接受的字符
        #region 获得用户IP
        /// <summary>获得用户IP</summary>
        public static string GetUserIp()
        {
            string ip;
            string[] temp;
            bool isErr = false;
            if (System.Web.HttpContext.Current.Request.ServerVariables["HTTP_X_ForWARDED_For"] == null)
                ip = System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"].ToString();
            else
                ip = System.Web.HttpContext.Current.Request.ServerVariables["HTTP_X_ForWARDED_For"].ToString();
            if (ip.Length > 15)
                isErr = true;
            else
            {
                temp = ip.Split('.');
                if (temp.Length == 4)
                {
                    for (int i = 0; i < temp.Length; i++)
                    {
                        if (temp[i].Length > 3) isErr = true;
                    }
                }
                else
                    isErr = true;
            }
            if (isErr)
                return "1.1.1.1";
            else
                return ip;
        }
        #endregion 获得用户IP
        #region 根据配置对指定字符串进行 MD5 加密
        /// <summary>根据配置对指定字符串进行 MD5 加密</summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static string GetMD5(string s)
        {
            //md5加密
            s = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(s, "md5").ToString();
            return s.ToLower().Substring(8, 16);
        }
        #endregion 根据配置对指定字符串进行 MD5 加密
        #region 得到字符串长度，一个汉字长度为2
        /// <summary>得到字符串长度，一个汉字长度为2</summary>
        /// <param name="inputString">参数字符串</param>
        /// <returns></returns>
        public static int StrLength(string inputString)
        {
            System.Text.ASCIIEncoding ascii = new System.Text.ASCIIEncoding();
            int tempLen = 0;
            byte[] s = ascii.GetBytes(inputString);
            for (int i = 0; i < s.Length; i++)
            {
                if ((int)s[i] == 63)
                    tempLen += 2;
                else
                    tempLen += 1;
            }
            return tempLen;
        }
        #endregion 得到字符串长度，一个汉字长度为2
        #region 截取指定长度字符串
        /// <summary>截取指定长度字符串</summary>
        /// <param name="inputString">要处理的字符串</param>
        /// <param name="len">指定长度</param>
        /// <returns>返回处理后的字符串</returns>
        public static string ClipString(string inputString, int len)
        {
            bool isShowFix = false;
            if (len % 2 == 1)
            {
                isShowFix = true;
                len--;
            }
            System.Text.ASCIIEncoding ascii = new System.Text.ASCIIEncoding();
            int tempLen = 0;
            string tempString = "";
            byte[] s = ascii.GetBytes(inputString);
            for (int i = 0; i < s.Length; i++)
            {
                if ((int)s[i] == 63)
                    tempLen += 2;
                else
                    tempLen += 1;
                try
                {
                    tempString += inputString.Substring(i, 1);
                }
                catch
                {
                    break;
                }
                if (tempLen > len)
                    break;
            }
            byte[] mybyte = System.Text.Encoding.Default.GetBytes(inputString);
            if (isShowFix && mybyte.Length > len)
                tempString += "…";
            return tempString;
        }
        #endregion 截取指定长度字符串
        #region 获得两个日期的间隔
        /// <summary>获得两个日期的间隔</summary>
        /// <param name="DateTime1">日期一。</param>
        /// <param name="DateTime2">日期二。</param>
        /// <returns>日期间隔TimeSpan。</returns>
        public static TimeSpan DateDiff(DateTime DateTime1, DateTime DateTime2)
        {
            TimeSpan ts1 = new TimeSpan(DateTime1.Ticks);
            TimeSpan ts2 = new TimeSpan(DateTime2.Ticks);
            TimeSpan ts = ts1.Subtract(ts2).Duration();
            return ts;
        }
        #endregion 获得两个日期的间隔
        #region 格式化日期时间
        /// <summary>格式化日期时间</summary>
        /// <param name="dateTime1">日期时间</param>
        /// <param name="dateMode">显示模式</param>
        /// <returns>0-9种模式的日期</returns>
        public static string FormatDate(DateTime dateTime1, string dateMode)
        {
            switch (dateMode)
            {
                case "0":
                    return dateTime1.ToString("yyyy-MM-dd");
                case "1":
                    return dateTime1.ToString("yyyy-MM-dd HH:mm:ss");
                case "2":
                    return dateTime1.ToString("yyyy/MM/dd");
                case "3":
                    return dateTime1.ToString("yyyy年MM月dd日");
                case "4":
                    return dateTime1.ToString("MM-dd");
                case "5":
                    return dateTime1.ToString("MM/dd");
                case "6":
                    return dateTime1.ToString("MM月dd日");
                case "7":
                    return dateTime1.ToString("yyyy-MM");
                case "8":
                    return dateTime1.ToString("yyyy/MM");
                case "9":
                    return dateTime1.ToString("yyyy年MM月");
                default:
                    return dateTime1.ToString();
            }
        }
        #endregion 格式化日期时间
        #region 得到随机日期
        /// <summary>得到随机日期</summary>
        /// <param name="time1">起始日期</param>
        /// <param name="time2">结束日期</param>
        /// <returns>间隔日期之间的 随机日期</returns>
        public static DateTime GetRandomTime(DateTime time1, DateTime time2)
        {
            Random random = new Random();
            DateTime minTime = new DateTime();
            DateTime maxTime = new DateTime();
            System.TimeSpan ts = new System.TimeSpan(time1.Ticks - time2.Ticks);
            // 获取两个时间相隔的秒数
            double dTotalSecontds = ts.TotalSeconds;
            int iTotalSecontds = 0;
            if (dTotalSecontds > System.Int32.MaxValue)
            {
                iTotalSecontds = System.Int32.MaxValue;
            }
            else if (dTotalSecontds < System.Int32.MinValue)
            {
                iTotalSecontds = System.Int32.MinValue;
            }
            else
            {
                iTotalSecontds = (int)dTotalSecontds;
            }
            if (iTotalSecontds > 0)
            {
                minTime = time2;
                maxTime = time1;
            }
            else if (iTotalSecontds < 0)
            {
                minTime = time1;
                maxTime = time2;
            }
            else
            {
                return time1;
            }
            int maxValue = iTotalSecontds;
            if (iTotalSecontds <= System.Int32.MinValue)
                maxValue = System.Int32.MinValue + 1;
            int i = random.Next(System.Math.Abs(maxValue));
            return minTime.AddSeconds(i);
        }
        #endregion 得到随机日期
        #region HTML转行成TEXT
        /// <summary>HTML转行成TEXT</summary>
        /// <param name="strHtml"></param>
        /// <returns></returns>
        public static string HtmlToTxt(string strHtml)
        {
            string[] aryReg ={
            @"<script[^>]*?>.*?</script>",
            @"<(\/\s*)?!?((\w+:)?\w+)(\w+(\s*=?\s*(([""'])(\\[""'tbnr]|[^\7])*?\7|\w+)|.{0})|\s)*?(\/\s*)?>",
            @"([\r\n])[\s]+",
            @"&(quot|#34);",
            @"&(amp|#38);",
            @"&(lt|#60);",
            @"&(gt|#62);",
            @"&(nbsp|#160);",
            @"&(iexcl|#161);",
            @"&(cent|#162);",
            @"&(pound|#163);",
            @"&(copy|#169);",
            @"&#(\d+);",
            @"-->",
            @"<!--.*\n"
            };
            string newReg = aryReg[0];
            string strOutput = strHtml;
            for (int i = 0; i < aryReg.Length; i++)
            {
                Regex regex = new Regex(aryReg[i], RegexOptions.IgnoreCase);
                strOutput = regex.Replace(strOutput, string.Empty);
            }
            strOutput.Replace("<", "");
            strOutput.Replace(">", "");
            strOutput.Replace("\r\n", "");
            return strOutput;
        }
        #endregion HTML转行成TEXT
        /// <summary>
        /// include 的摘要说明。
        /// </summary>
        #region 字符串截取函数
        /// <summary>
        /// 字符串截取函数
        /// </summary>
        /// <param name="inputString">要截取的字符串</param>
        /// <param name="len">要截取的长度</param>
        /// <returns>string</returns>
        ///
        public static string CutString(string inputString, int len)
        {
            ASCIIEncoding ascii = new ASCIIEncoding();
            int tempLen = 0;
            string tempString = "";
            byte[] s = ascii.GetBytes(inputString);
            for (int i = 0; i < s.Length; i++)
            {
                if ((int)s[i] == 63)
                {
                    tempLen += 2;
                }
                else
                {
                    tempLen += 1;
                }
                try
                {
                    tempString += inputString.Substring(i, 1);
                }
                catch
                {
                    break;
                }
                if (tempLen > len)
                    break;
            }
            //   //如果截过则加上半个省略号
            byte[] mybyte = System.Text.Encoding.Default.GetBytes(inputString);
            if (mybyte.Length > len)
                tempString += "…";
            return tempString;
        }
        #endregion 字符串截取函数
        #region 生成由日期组成的唯一的文件名
        /// <summary>
        /// 生成由日期组成的唯一的文件名
        /// </summary>
        /// <returns>string</returns>
        ///
        public string makeFileName()
        {
            string newFileName;
            string dateName = System.DateTime.Now.ToString("yyyyMMddhhmmss");
            System.Random srd = new Random();
            int srdName = srd.Next(1000);
            newFileName = dateName + srdName.ToString();
            return newFileName;
        }
        #endregion 生成由日期组成的唯一的文件名
        #region 过滤特殊字符
        /// <summary>
        /// 过滤特殊字符
        /// </summary>
        /// <param name="inputStr">字符串</param>
        /// <returns>string</returns>
        public string cutBadStr(string inputStr)
        {
            //inputStr = inputStr.Replace(",", "");
            inputStr = inputStr.Replace("<", "&lt;");
            inputStr = inputStr.Replace(">", "&gt;");
            inputStr = inputStr.Replace("%", "");
            //inputStr = inputStr.Replace(".", "");
            inputStr = inputStr.Replace(":", "");
            inputStr = inputStr.Replace("#", "");
            inputStr = inputStr.Replace("&", "");
            inputStr = inputStr.Replace("$", "");
            inputStr = inputStr.Replace("^", "");
            inputStr = inputStr.Replace("*", "");
            inputStr = inputStr.Replace("`", "");
            inputStr = inputStr.Replace(" ", "");
            inputStr = inputStr.Replace("~", "");
            Regex regex1 = new Regex(@" or ", RegexOptions.IgnoreCase);
            inputStr = regex1.Replace(inputStr, "");
            Regex regex2 = new Regex(@" and ", RegexOptions.IgnoreCase);
            inputStr = regex2.Replace(inputStr, "");
            return inputStr;
        }
        #endregion 过滤特殊字符
        #region 过滤html标记
        /// <summary>
        /// 过滤html标记
        /// </summary>
        /// <param name="HTMLStr">要过滤的字符串</param>
        /// <returns>string</returns>
        ///
        public string replaceEncode(string str)
        {
            return str.Replace("+", "%20").Replace("%3a", ":");
        }
        public string clearHtml(string strhtml, int sum)
        {
            Regex ar = new Regex("<[^>]+>", RegexOptions.Compiled);
            string output = strhtml.Replace(" ", "");
            output = ar.Replace(output, "");
            //output = output.Replace("<", "");
            if (output.Length > sum)
            {
                output = output.Remove(sum);
            }
            return output;
        }
        public string CutHTML(string strHtml)
        {
            string[] aryReg ={
          @"<script[^>]*?>.*?</script>",
    @"<%",
    @"%>",
          @"<(\/\s*)?!?((\w+:)?\w+)(\w+(\s*=?\s*(([""'])(\\[""'tbnr]|[^\7])*?\7|\w+)|.{0})|\s)*?(\/\s*)?>",
          @"([ ])[\s]+",
          @"&(quot|#34);",
          @"&(amp|#38);",
          @"&(lt|#60);",
          @"&(gt|#62);",
          @"&(nbsp|#160);",
          @"&(iexcl|#161);",
          @"&(cent|#162);",
          @"&(pound|#163);",
          @"&(copy|#169);",
          @"&#(\d+);",
          @"-->",
          @"<!--.* "  ,
 @"<iframe[\s\S]+</iframe *>",
 @"<frameset[\s\S]+</frameset *>",
 @"\r\n"
                             };
            string[] aryRep =   {
             "",
             "",
             "",
                          "",
             "",
             "\"",
             "&",
             "<",
             ">",
             "   ",
             "\xa1",//chr(161),
             "\xa2",//chr(162),
             "\xa3",//chr(163),
             "\xa9",//chr(169),
             "",
             " ",
             "",
             "",
             "",
             ""
            };
            string newReg = aryReg[0];
            string strOutput = strHtml;
            for (int i = 0; i < aryReg.Length; i++)
            {
                Regex regex = new Regex(aryReg[i], RegexOptions.IgnoreCase);
                strOutput = regex.Replace(strOutput, aryRep[i]);
            }
            strOutput.Replace("<", "");
            strOutput.Replace(">", "");
            strOutput.Replace(" ", "");
            return strOutput;
        }
        #endregion 过滤html标记
        public static string checkStr(string html)
        {
            Regex regex1 = new Regex(@"<script[\s\S]+</script *>", RegexOptions.IgnoreCase);
            Regex regex2 = new Regex(@" href *= *[\s\S]*script *:", RegexOptions.IgnoreCase);
            Regex regex3 = new Regex(@" no[\s\S]*=", RegexOptions.IgnoreCase);
            Regex regex4 = new Regex(@"<iframe[\s\S]+</iframe *>", RegexOptions.IgnoreCase);
            Regex regex5 = new Regex(@"<frameset[\s\S]+</frameset *>", RegexOptions.IgnoreCase);
            Regex regex6 = new Regex(@"\<img[^\>]+\>", RegexOptions.IgnoreCase);
            Regex regex7 = new Regex(@"</p>", RegexOptions.IgnoreCase);
            Regex regex8 = new Regex(@"<p>", RegexOptions.IgnoreCase);
            Regex regex9 = new Regex(@"<[^>]*>", RegexOptions.IgnoreCase);
            html = regex1.Replace(html, ""); //过滤<script></script>标记
            html = regex2.Replace(html, ""); //过滤href=javascript: (<A>) 属性
            html = regex3.Replace(html, " _disibledevent="); //过滤其它控件的on...事件
            html = regex4.Replace(html, ""); //过滤iframe
            html = regex5.Replace(html, ""); //过滤frameset
            // html = regex6.Replace(html, ""); //过滤frameset
            //  html = regex7.Replace(html, ""); //过滤frameset
            // html = regex8.Replace(html, ""); //过滤frameset
            //  html = regex9.Replace(html, "");
            // html = html.Replace(" ", "");
            // html = html.Replace("</strong>", "");
            // html = html.Replace("<strong>", "");
            // html = cutBadStr(html);
            html = html.Replace("<%", "");
            html = html.Replace("%>", "");
            html = html.Replace("<?", "");
            html = html.Replace("?>", "");
            return html;
        }
        #region 标题固定长度
        /// <summary>
        /// <table style="font-size:12px">
        /// <tr><td><b>功能描述</b>：填充或截断原始字符串为指定长度 </td></tr>
        /// <tr><td><b>创 建 人</b>： </td></tr>
        /// <tr><td><b>创建时间</b>：</td></tr>
        /// </table>
        /// </summary>
        /// <param name="strOriginal">原始字符串</param>
        /// <param name="maxTrueLength">字符串的字节长度</param>
        /// <param name="chrPad">填充字符</param>
        /// <param name="blnCutTail">字符串的字节长度超过maxTrueLength时截断多余字符</param>
        /// <returns>填充或截断后的字符串</returns>
        public string PadRightTrueLen(string strOriginal, int maxTrueLength, char chrPad, bool blnCutTail)
        {
            string strNew = strOriginal;
            if (strOriginal == null || maxTrueLength <= 0)
            {
                strNew = "";
                return strNew;
            }
            int trueLen = TrueLength(strOriginal);
            if (trueLen > maxTrueLength)//超过maxTrueLength
            {
                if (blnCutTail)//截断
                {
                    for (int i = strOriginal.Length - 1; i > 0; i--)
                    {
                        strNew = strNew.Substring(0, i);
                        if (TrueLength(strNew) == maxTrueLength)
                            break;
                        else if (TrueLength(strNew) < maxTrueLength)
                        {
                            strNew += chrPad.ToString();
                            break;
                        }
                    }
                }
            }
            else//填充
            {
                for (int i = 0; i < maxTrueLength - trueLen; i++)
                {
                    strNew += chrPad.ToString();
                }
            }
            return strNew;
        }
        //主方法
        public string CutStringTitle(string inputString, int i)
        {
            return PadRightTrueLen(inputString, i, ' ', true);
        }
        /// <summary>
        ///  字符串的字节长度  
        /// </summary>
        /// <param name="str">字符串</param>
        /// <returns>字符串的字节长度</returns>
        public int TrueLength(string str)
        {
            int lenTotal = 0;
            int n = str.Length;
            string strWord = "";
            int asc;
            for (int i = 0; i < n; i++)
            {
                strWord = str.Substring(i, 1);
                asc = Convert.ToChar(strWord);
                if (asc < 0 || asc > 127)
                    lenTotal = lenTotal + 2;
                else
                    lenTotal = lenTotal + 1;
            }
            return lenTotal;
        }
        #endregion 标题固定长度
        #region 返回不重复随机数数组
        /// <summary>
        /// 返回不重复随机数数组
        /// </summary>
        /// <param name="Num">随机数个数</param>
        /// <param name="minNum">随机数下限</param>
        /// <param name="maxNum">随机数上限</param>
        /// <returns></returns>
        public int[] GetRandomArray(int Number, int minNum, int maxNum)
        {
            int j;
            int[] b = new int[Number];
            Random r = new Random();
            for (j = 0; j < Number; j++)
            {
                int i = r.Next(minNum, maxNum + 1);
                int num = 0;
                for (int k = 0; k < j; k++)
                {
                    if (b[k] == i)
                    {
                        num = num + 1;
                    }
                }
                if (num == 0)
                {
                    b[j] = i;
                }
                else
                {
                    j = j - 1;
                }
            }
            return b;
        }
        #endregion 返回不重复随机数数组
        #region 计算字符串字节
        ///   <summary>
        ///   判断一个字符串的字节数量
        ///   </summary>
        ///   <param   name="theString"></param>
        ///   <returns></returns>
        ///
        public static int StringLength(string theString)
        {
            int theLength = 0;
            for (int i = 0; i < theString.Length; i++)
            {
                if ((short)(Convert.ToChar(theString.Substring(i, 1))) > 255 || (short)(Convert.ToChar(theString.Substring(i, 1))) < 0)
                {
                    theLength += 2;
                }
                else
                {
                    theLength += 1;
                }
            }
            return theLength;
        }
        #endregion 计算字符串字节
        #region 提取中文首字母
        //需引用using System.Text;
        static public string GetChineseSpell(string strText)
        {
            int len = strText.Length;
            string myStr = "";
            for (int i = 0; i < len; i++)
            {
                myStr += getSpell(strText.Substring(i, 1));
            }
            return myStr;
        }
        static public string getSpell(string cnChar)
        {
            byte[] arrCN = Encoding.Default.GetBytes(cnChar);
            if (arrCN.Length > 1)
            {
                int area = (short)arrCN[0];
                int pos = (short)arrCN[1];
                int code = (area << 8) + pos;
                int[] areacode = { 45217, 45253, 45761, 46318, 46826, 47010, 47297, 47614, 48119, 48119, 49062, 49324, 49896, 50371, 50614, 50622, 50906, 51387, 51446, 52218, 52698, 52698, 52698, 52980, 53689, 54481 };
                for (int i = 0; i < 26; i++)
                {
                    int max = 55290;
                    if (i != 25) max = areacode[i + 1];
                    if (areacode[i] <= code && code < max)
                    {
                        return Encoding.Default.GetString(new byte[] { (byte)(97 + i) });
                    }
                }
                return "*";
            }
            else return cnChar;
        }
        #endregion 提取中文首字母
        #region 文本框格式化(value=?使用)
        ///   <summary>
        ///   过滤输出字符串
        ///   </summary>
        ///   <param   name="inputString">要过滤的字符串</param>
        ///   <returns>过滤后的字符串</returns>
        public static string Output(object inputString)
        {
            if (inputString == null)
                return string.Empty;
            string str1 = HttpContext.Current.Server.HtmlEncode(inputString.ToString());
            str1 = str1.Replace("&amp;", "&");
            str1 = str1.Replace("&lt;", "<");
            str1 = str1.Replace("&gt;", ">");
            str1 = str1.Replace("&quot;", ((char)34).ToString());
            return str1.ToString();
            //前台显示DataBinder.Eval(Container.DataItem,   "Content").ToString().Replace("<","&lt;").Replace(">","&gt;").Replace("\r\n","<br>").Replace("   ","&nbsp;")
        }
        #endregion 文本框格式化(value=?使用)
        #region 文本框格式化(前台显示=?使用)
        ///   <summary>
        ///   过滤输出字符串
        ///   </summary>
        ///   <param   name="inputString">要过滤的字符串</param>
        ///   <returns>过滤后的字符串</returns>
        public static string Outhtml(object htmlString)
        {
            if (htmlString == null)
                return string.Empty;
            string str2 = HttpContext.Current.Server.HtmlEncode(htmlString.ToString());
            str2 = str2.Replace("&", "&amp;");
            str2 = str2.Replace("<", "&lt;");
            str2 = str2.Replace(">", "&gt;");
            str2 = str2.Replace(((char)34).ToString(), "&quot;");
            str2 = str2.Replace("\r\n", "<br>");
            return str2.ToString();
            //前台显示DataBinder.Eval(Container.DataItem,   "Content").ToString().Replace("<","&lt;").Replace(">","&gt;").Replace("\r\n","<br>").Replace("   ","&nbsp;")
        }
        #endregion 文本框格式化(前台显示=?使用)
        #region 半角转全角(SBC case)
        /// <summary>
        /// 转全角的函数(SBC case)
        /// </summary>
        /// <param name="input">任意字符串</param>
        /// <returns>全角字符串</returns>
        ///<remarks>
        ///全角空格为12288，半角空格为32
        ///其他字符半角(33-126)与全角(65281-65374)的对应关系是：均相差65248
        ///</remarks>
        public static string ToSBC(string input)
        {
            //半角转全角：
            char[] c = input.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] == 32)
                {
                    c[i] = (char)12288;
                    continue;
                }
                if (c[i] < 127)
                    c[i] = (char)(c[i] + 65248);
            }
            return new string(c);
        }
        #endregion 半角转全角(SBC case)
        #region 全角转半角(DBC case)
        /// <summary>
        /// 转半角的函数(DBC case)
        /// </summary>
        /// <param name="input">任意字符串</param>
        /// <returns>半角字符串</returns>
        ///<remarks>
        ///全角空格为12288，半角空格为32
        ///其他字符半角(33-126)与全角(65281-65374)的对应关系是：均相差65248
        ///</remarks>
        public static string ToDBC(string input)
        {
            char[] c = input.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] == 12288)
                {
                    c[i] = (char)32;
                    continue;
                }
                if (c[i] > 65280 && c[i] < 65375)
                    c[i] = (char)(c[i] - 65248);
            }
            return new string(c);
        }
        #endregion 全角转半角(DBC case)
        #region 字符串截取函数，截取左边指定的字节数
        /// <summary>
        /// 字符串截取函数，截取左边指定的字节数
        /// </summary>
        /// <param name="text">输入字符串</param>
        /// <param name="CutLength">截取长度</param>
        /// <returns>返回处理后的字符串</returns>
        public static string cutStr(string text, int CutLength)
        {
            if (text == null || text.Length == 0 || CutLength <= 0)
                return "";
            int iCount = System.Text.Encoding.GetEncoding("Shift_JIS").GetByteCount(text);
            if (iCount > CutLength)
            {
                int iLength = 0;
                for (int i = 0; i < text.Length; i++)
                {
                    int iCharLength = System.Text.Encoding.GetEncoding("Shift_JIS").GetByteCount(new char[] { text[i] });
                    iLength += iCharLength;
                    if (iLength == CutLength)
                    {
                        text = text.Substring(0, i + 1);
                        break;
                    }
                    else if (iLength > CutLength)
                    {
                        text = text.Substring(0, i);
                        break;
                    }
                }
            }
            return text;
        }
        #endregion 字符串截取函数，截取左边指定的字节数
        #region 使用正则表达式删除用户输入中的html内容
        /// <summary>
        /// 使用正则表达式删除用户输入中的html内容
        /// </summary>
        /// <param name="text">输入内容</param>
        /// <returns>清理后的文本</returns>
        public static string clearHtml(string text)
        {
            string pattern;
            if (text.Length == 0)
                return text;
            pattern = @"(<[a-zA-Z].*?>)|(<[\/][a-zA-Z].*?>)";
            text = Regex.Replace(text, pattern, String.Empty, RegexOptions.IgnoreCase);
            text = text.Replace("<", "<");
            text = text.Replace(">", ">");
            return text;
        }
        public static string reHtml(string text)
        {
            text = text.Replace(" ", " ");
            text = text.Replace("<br />", "\n");
            return text;
        }
        #endregion 使用正则表达式删除用户输入中的html内容
        #region 使用正则表达式删除用户输入中的JS脚本内容
        /// <summary>
        /// 使用正则表达式删除用户输入中的JS脚本内容
        /// </summary>
        /// <param name="text">输入内容</param>
        /// <returns>清理后的文本</returns>
        public static string clearScript(string text)
        {
            string pattern;
            if (text.Length == 0)
                return text;
            pattern = @"(?i)<script([^>])*>(\w|\W)*</script([^>])*>";
            text = Regex.Replace(text, pattern, String.Empty, RegexOptions.IgnoreCase);
            pattern = @"<script([^>])*>";
            text = Regex.Replace(text, pattern, String.Empty, RegexOptions.IgnoreCase);
            pattern = @"</script>";
            text = Regex.Replace(text, pattern, String.Empty, RegexOptions.IgnoreCase);
            return text;
        }
        #endregion 使用正则表达式删除用户输入中的JS脚本内容
        #region 过滤SQL,所有涉及到输入的用户直接输入的地方都要使用
        /// <summary>
        /// 过滤SQL,所有涉及到输入的用户直接输入的地方都要使用。
        /// </summary>
        /// <param name="text">输入内容</param>
        /// <returns>过滤后的文本</returns>
        public static string filterSQL(string text)
        {
            text = text.Replace("'", "''");
            text = text.Replace("{", "{");
            text = text.Replace("}", "}");
            return text;
        }
        #endregion 过滤SQL,所有涉及到输入的用户直接输入的地方都要使用
        #region 过滤SQL,将SQL字符串里面的(')转换成('')，再在字符串的两边加上(')
        /// <summary>
        /// 将SQL字符串里面的(')转换成('')，再在字符串的两边加上(')。
        /// </summary>
        /// <param name="text">输入内容</param>
        /// <returns>过滤后的文本</returns>
        public static String GetQuotedString(String text)
        {
            return ("'" + filterSQL(text) + "'");
        }
        #endregion 过滤SQL,将SQL字符串里面的(')转换成('')，再在字符串的两边加上(')
        #region 判断字符串是否为数字
        /// <summary>
        /// 判断字符串是否为数字
        /// </summary>
        /// <param name="str">输入字符串</param>
        /// <returns>true为是，false为否</returns>
        public static bool isNumeric(string str)
        {
            if (str == null || str.Length == 0)
                return false;
            foreach (char c in str)
            {
                if (!Char.IsNumber(c))
                {
                    return false;
                }
            }
            return true;
        }
        #endregion 判断字符串是否为数字
        #region 空格转换为逗号
        /// <summary>
        /// 空格转换为逗号
        /// </summary>
        /// <param name="strTags"></param>
        /// <returns></returns>
        public static string space2comma(string strIn)
        {
            strIn = strIn.Replace(" ", ",");
            return strIn;
        }
        public static string comma2space(string strIn)
        {
            strIn = strIn.Replace(",", " ");
            return strIn;
        }
        #endregion 空格转换为逗号
        #region 1位计数转换为2位
        /// <summary>
        /// 1位计数转换为2位
        /// </summary>
        /// <param name="strIn"></param>
        /// <returns></returns>
        public static string one2two(int strIn)
        {
            if (strIn.ToString().Length < 2)
            {
                return "0" + strIn.ToString();
            }
            else
            {
                return strIn.ToString();
            }
        }
        #endregion 1位计数转换为2位
        #region 自动识别文本中的URL
        /// <summary>
        /// 自动识别文本中的URL
        /// 可以识别 www.，http://， ftp://， xx@xx.xx， mms://
        /// </summary>
        /// <param name="input">输入数据</param>
        /// <returns>自动识别URL后的数据</returns>
        public static string autoConvertToURL(object input)
        {
            string str = input.ToString();
            Regex Reg;
            Reg = new Regex("([^\\]=>])(http://[A-Za-z0-9\\./=\\?%\\-&_~`@':+!]+)");
            str = Reg.Replace(str, "$1<a href=\"$2\" target=\"_blank\">$2</a>");
            Reg = new Regex("^(http://[A-Za-z0-9\\./=\\?%\\-&_~`@':+!]+)");
            str = Reg.Replace(str, "<a href=\"$1\" target=\"_blank\">$1</a>");
            Reg = new Regex("(http://[A-Za-z0-9\\./=\\?%\\-&_~`@':+!]+)$");
            str = Reg.Replace(str, "<a href=\"$1\" target=\"_blank\">$1</a>");
            Reg = new Regex("([^\\]=>])(ftp://[A-Za-z0-9\\./=\\?%\\-&_~`@':+!]+)");
            str = Reg.Replace(str, "$1<a href=\"$2\" target=\"_blank\">$2</a>");
            Reg = new Regex("^(ftp://[A-Za-z0-9\\./=\\?%\\-&_~`@':+!]+)");
            str = Reg.Replace(str, "<a href=\"$1\" target=\"_blank\">$1</a>");
            Reg = new Regex("(ftp://[A-Za-z0-9\\./=\\?%\\-&_~`@':+!]+)$");
            str = Reg.Replace(str, "<a href=\"$1\" target=\"_blank\">$1</a>");
            Reg = new Regex("([^\\]=>])(mms://[A-Za-z0-9\\./=\\?%\\-&_~`@':+!]+)");
            str = Reg.Replace(str, "$1<a href=\"$2\" target=\"_blank\">$2</a>");
            Reg = new Regex("^(mms://[A-Za-z0-9\\./=\\?%\\-&_~`@':+!]+)");
            str = Reg.Replace(str, "<a href=\"$1\" target=\"_blank\">$1</a>");
            Reg = new Regex("(mms://[A-Za-z0-9\\./=\\?%\\-&_~`@':+!]+)$");
            str = Reg.Replace(str, "<a href=\"$1\" target=\"_blank\">$1</a>");
            Reg = new Regex("([a-z0-9_A-Z\\-\\.]{1,20})@([a-z0-9_\\-]{1,15})\\.([a-z]{2,4})");
            str = Reg.Replace(str, "<a href=\"mailto:$1@$2.$3\" target=\"_blank\">$1@$2.$3</a>");
            Reg = new Regex("([^/])(www.[A-Za-z0-9\\./=\\?%\\-&_~`@':+!]+)");
            str = Reg.Replace(str, "$1<a href=\"http://$2\" target=\"_blank\">$2</a>");
            Reg = new Regex("^(www.[A-Za-z0-9\\./=\\?%\\-&_~`@':+!]+)");
            str = Reg.Replace(str, "<a href=\"http://$1\" target=\"_blank\">$1</a>");
            Reg = new Regex("(www.[A-Za-z0-9\\./=\\?%\\-&_~`@':+!]+)$");
            str = Reg.Replace(str, "<a href=\"http://$1\" target=\"_blank\">$1</a>");
            return str;
        }
        #endregion 自动识别文本中的URL
        #region 检查邮件正确性
        /// <summary>
        /// 检查邮件正确性
        /// </summary>
        /// <param name="inputEmail">输入的邮件地址</param>
        /// <returns>返回BOOL值</returns>
        public static bool isEmail(string inputEmail)
        {
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            Regex re = new Regex(strRegex);
            if (re.IsMatch(inputEmail))
                return (true);
            else
                return (false);
        }
        #endregion 检查邮件正确性
        #region 替换XML文档不接受的字符
        /// <summary>
        /// 替换XML文档不接受的字符
        /// </summary>
        /// <param name="input">传入值</param>
        /// <returns>替换后的字符</returns>
        public static string formatForXML(object input)
        {
            string str = input.ToString();
            //替换XML文档不接受的字符
            str = str.Replace(" ", " ");
            str = str.Replace("&", "&");
            str = str.Replace("\"", "''");
            str = str.Replace("'", "&apos;");
            return str;
        }
        #endregion 替换XML文档不接受的字符
        #region Split数组处理
        /// <summary>
        /// 
        /// </summary>
        /// <param name="str"></param>
        /// <param name="separator"></param>
        /// <returns></returns>
        static public string[] SplitString(string str, string separator)
        {
            string tmp = str;
            Hashtable ht = new Hashtable();
            int i = 0;
            int pos = tmp.IndexOf(separator);
            while (pos != -1)
            {
                ht.Add(i, tmp.Substring(0, pos));
                tmp = tmp.Substring(pos + separator.Length);
                pos = tmp.IndexOf(separator);
                i++;
            }
            ht.Add(i, tmp);
            string[] array = new string[ht.Count];
            for (int j = 0; j < ht.Count; j++)
                array[j] = ht[j].ToString();
            return array;
        }
        #endregion Split数组处理
        #region AjaxPro使用的分页方法
        /// <summary>
        /// 使用AjaxPro时候使用的方法
        /// </summary>
        /// <param name="pageIndex">第几页</param>
        /// <param name="pageIndex">总共多少页</param>
        /// <param name="pageIndex">当前页条数</param>
        /// <param name="pageIndex">总条数</param>
        /// <returns>分页导航</returns>
        public static string AjaxPages(int pageIndex, int pageCount, int roscount, int counts)
        {
            StringBuilder text = new StringBuilder();
            //新的分页
            text.Append("<br><TABLE class='tableborder' cellSpacing='1' cellPadding='3' width='98%'  border='0' align='center'>");
            text.Append("<td align='left' width='250px'>第" + pageIndex + "页/总" + pageCount + "页　本页" + roscount + "条/总" + counts + "条 </td>");
            text.Append("<td align='left' width='40px'><a href='javascript:JumpPage(1)'>首页</a></td>");
            if (pageIndex < pageCount)
            {
                text.Append("<td align='left' width='40px'><a href='javascript:JumpPage(" + (pageIndex + 1) + ")'>下一页</a></td>");
            }
            else
            {
                text.Append("<td align='left' width='40px'>下一页</a></td>");
            }
            if (pageIndex > 1)
            {
                text.Append("<td align='left' width='40px'><a href='javascript:JumpPage(" + (pageIndex - 1) + ")'>上一页</a></td>");
            }
            else
            {
                text.Append("<td align='left' width='40px'>上一页</a></td>");
            }
            text.Append("<td align='left' width='40px'><a href='javascript:JumpPage(" + pageCount + ")'>尾页</a><td>");
            int BasePage = (pageIndex / 10) * 10;
            if (BasePage > 0)
            {
                text.Append("<td align='left' width='20px'><a href='javascript:JumpPage(" + (BasePage - 9) + ")'>&lt;&lt;</a></td>");
            }
            for (int j = 1; j < 11; j++)
            {
                int PageNumber = BasePage + j;
                if (PageNumber > pageCount)
                {
                    break;
                }
                if (PageNumber == Convert.ToInt32(pageIndex))
                {
                    text.Append("<td align='left' width='20px'><font color='#FF0000'>" + PageNumber + "</font></td>");
                }
                else
                {
                    text.Append("<td align='left' width='20px'><a href='javascript:JumpPage(" + PageNumber + ")'>" + PageNumber + "</a></td>");
                }
            }
            if (pageCount - 1 > BasePage)
            {
                text.Append("<td align='left' width='20px'><a href='javascript:JumpPage(" + (BasePage + 11) + ")'>&gt;&gt;</a></td>");
            }
            text.Append("</table>");
            return text.ToString();
        }
        #endregion AjaxPro使用的分页方法
        public enum SortType
        {
            /// <summary>
            ///
            /// </summary>
            Photo = 1,
            /// <summary>
            ///
            /// </summary>
            Article = 5,
            /// <summary>
            ///
            /// </summary>
            Diary = 7,
            /// <summary>
            ///
            /// </summary>
            Pic = 2,
            /// <summary>
            ///
            /// </summary>
            Music = 6,
            /// <summary>
            ///
            /// </summary>
            AddressList = 4,
            /// <summary>
            ///
            /// </summary>
            Favorite = 3,
        }
        #region 根据给出的相对地址获取网站绝对地址
        /// <summary>根据给出的相对地址获取网站绝对地址</summary>
        /// <param name="localPath">相对地址</param>
        /// <returns>绝对地址</returns>
        public static string GetWebPath(string localPath)
        {
            string path = HttpContext.Current.Request.ApplicationPath;
            string thisPath;
            string thisLocalPath;
            //如果不是根目录就加上"/" 根目录自己会加"/"
            if (path != "/")
            {
                thisPath = path + "/";
            }
            else
            {
                thisPath = path;
            }
            if (localPath.StartsWith("~/"))
            {
                thisLocalPath = localPath.Substring(2);
            }
            else
            {
                return localPath;
            }
            return thisPath + thisLocalPath;
        }
        #endregion 根据给出的相对地址获取网站绝对地址
        #region 获取网站绝对地址
        /// <summary>获取网站绝对地址</summary>
        /// <returns></returns>
        public static string GetWebPath()
        {
            string path = HttpContext.Current.Request.ApplicationPath;
            string thisPath;
            //如果不是根目录就加上"/" 根目录自己会加"/"
            if (path != "/")
            {
                thisPath = path + "/";
            }
            else
            {
                thisPath = path;
            }
            return thisPath;
        }
        #endregion 获取网站绝对地址
        #region 根据相对路径或绝对路径获取绝对路径
        /// <summary>根据相对路径或绝对路径获取绝对路径</summary>
        /// <param name="localPath">相对路径或绝对路径</param>
        /// <returns>绝对路径</returns>
        public static string GetFilePath(string localPath)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(localPath, @"([A-Za-z]):\\([\S]*)"))
            {
                return localPath;
            }
            else
            {
                return HttpContext.Current.Server.MapPath(localPath);
            }
        }
        #endregion 根据相对路径或绝对路径获取绝对路径
        #region 获取指定调用层级的方法名
        /// <summary>
        /// 获取指定调用层级的方法名
        /// </summary>
        /// <param name="level">调用的层数</param>
        public static string GetMethodName(int level)
        {
            //创建一个堆栈跟踪
            StackTrace trace = new StackTrace();
            //获取指定调用层级的方法名
            return trace.GetFrame(level).GetMethod().Name;
        }
        #endregion 获取指定调用层级的方法名
        #region 获取换行字符
        /// <summary>
        /// 获取换行字符
        /// </summary>
        public static string NewLine
        {
            get
            {
                return Environment.NewLine;
            }
        }
        #endregion 获取换行字符
        #region 获取当前应用程序域
        /// <summary>
        /// 获取当前应用程序域
        /// </summary>
        public static AppDomain CurrentAppDomain
        {
            get
            {
                return Thread.GetDomain();
            }
        }
        #endregion 获取当前应用程序域
        #region 获取Windows Form应用程序的名字
        /// <summary>
        /// 获取当前Windows Form应用程序的名字,不包括.exe
        /// </summary>
        public static string WinFormName
        {
            get
            {
                //获取应用程序的完全路径
                string appPath = "";//MediaTypeNames.Application.ExecutablePath;
                //找到最后一个'\'的位置
                int beginIndex = appPath.LastIndexOf(@"\");
                //找到".exe"的位置
                int endIndex = appPath.ToLower().LastIndexOf(".exe");
                //返回Windows Form应用程序的名字
                return appPath.Substring(beginIndex + 1, endIndex - beginIndex - 1);
            }
        }
        #endregion 获取Windows Form应用程序的名字
    }
}