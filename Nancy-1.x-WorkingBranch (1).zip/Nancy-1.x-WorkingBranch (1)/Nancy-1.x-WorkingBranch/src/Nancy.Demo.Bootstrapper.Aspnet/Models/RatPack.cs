﻿namespace Nancy.Demo.Bootstrapping.Aspnet.Models
{
    public class RatPack
    {
        public string FirstName { get; set; }
    }
}