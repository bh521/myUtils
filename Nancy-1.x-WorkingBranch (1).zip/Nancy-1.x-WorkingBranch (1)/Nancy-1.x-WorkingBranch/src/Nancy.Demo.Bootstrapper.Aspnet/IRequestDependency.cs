namespace Nancy.Demo.Bootstrapping.Aspnet
{
    public interface IRequestDependency
    {
        string GetContent();
    }
}