﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Nancy.Authentication.Token.Tests")]